import streamlit as st
import pandas as pd
import json
import matplotlib.pyplot as plt

from analysis import load_stats_df, compute_batting_kpis, compute_bowling_kpis, detect_patterns
from openai_client import ask_coach

st.set_page_config(page_title="MirrorPlay MVP", layout="wide")
st.title("MirrorPlay — AI Coach (MVP)")

uploaded_file = st.file_uploader("Upload stats CSV", type=["csv"])

if uploaded_file is None:
    st.info("Upload a CSV to begin. You can use sample_stats.csv as a template.")
    st.stop()

df = load_stats_df(uploaded_file)
st.subheader("Raw Data")
st.dataframe(df)

batting_df, batting_agg = compute_batting_kpis(df)
bowling_df, bowling_agg = compute_bowling_kpis(df)
patterns = detect_patterns(batting_df, bowling_df)

st.subheader("Aggregated KPIs")
cols = st.columns(2)
with cols[0]:
    st.markdown("**Batting KPIs**")
    if batting_agg:
        st.write(batting_agg)
    else:
        st.write("No batting records found.")
with cols[1]:
    st.markdown("**Bowling KPIs**")
    if bowling_agg:
        st.write(bowling_agg)
    else:
        st.write("No bowling records found.")

st.subheader("Trends")
if not batting_df.empty:
    st.markdown("**Runs over time**")
    fig, ax = plt.subplots()
    batting_df_sorted = batting_df.sort_values("date")
    ax.plot(batting_df_sorted['date'], batting_df_sorted['runs'], marker='o')
    ax.set_xlabel("Date")
    ax.set_ylabel("Runs")
    st.pyplot(fig)

st.subheader("Detected Patterns")
if patterns:
    for p in patterns:
        st.info(p)
else:
    st.write("No major patterns detected.")

st.subheader("AI Coach")
if st.button("Generate AI Coaching Advice"):
    summary_text = f"Batting aggregates: {batting_agg}\nBowling aggregates: {bowling_agg}"
    ai_resp = ask_coach(summary_text, patterns)
    st.markdown("**Raw AI response**")
    if isinstance(ai_resp, dict) and ai_resp.get("error"):
        st.error(f"OpenAI error: {ai_resp['error']}")
    else:
        try:
            parsed = json.loads(ai_resp)
            st.markdown("**Strengths**")
            for s in parsed.get("strengths", []):
                st.write("- " + s)
            st.markdown("**Weaknesses**")
            for s in parsed.get("weaknesses", []):
                st.write("- " + s)
            st.markdown("**Drills**")
            for d in parsed.get("drills", []):
                st.write("- " + d)
            st.markdown("**Weekly Plan**")
            for day, task in parsed.get("weekly_plan", {}).items():
                st.write(f"**{day}**: {task}")
        except Exception:
            st.write(ai_resp)
