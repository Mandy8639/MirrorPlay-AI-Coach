# MirrorPlay - MVP (Stat-based AI Coach)

## Vision
MirrorPlay is an AI-driven platform that analyzes match video or stats, builds a performance profile, and provides personalized coaching feedback, strategy tips, and opponent simulations.

## How to Run
1. pip install -r requirements.txt
2. export OPENAI_API_KEY="your_key_here"   # or use .env
3. streamlit run app.py

Upload a CSV with match stats (template in sample_stats.csv). The app computes KPIs and returns AI coaching tips.

## Sample
See `sample_stats.csv` for the expected data format.
