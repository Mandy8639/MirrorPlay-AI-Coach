import pandas as pd
import numpy as np

def load_stats_df(path_or_buffer):
    df = pd.read_csv(path_or_buffer, parse_dates=["date"])
    df.columns = [c.strip() for c in df.columns]
    return df

def compute_batting_kpis(df):
    batting = df[df['role'].str.contains('bat', case=False, na=False)].copy()
    if batting.empty:
        return pd.DataFrame(), {}
    batting['strike_rate'] = batting.apply(lambda r: (r['runs'] / r['balls'] * 100) if (r['balls'] and r['balls']>0) else np.nan, axis=1)
    batting['boundary_rate'] = batting.apply(lambda r: ((r.get('fours',0) + r.get('sixes',0)) / r['balls']) if (r['balls'] and r['balls']>0) else np.nan, axis=1)
    batting['dot_ball_pct'] = batting.apply(lambda r: (r.get('dot_balls',0) / r['balls']) if (r['balls'] and r['balls']>0) else np.nan, axis=1)
    agg = {
        'matches': len(batting),
        'avg_runs': batting['runs'].mean(),
        'median_sr': batting['strike_rate'].median(),
        'avg_boundary_rate': batting['boundary_rate'].mean(),
        'avg_dot_pct': batting['dot_ball_pct'].mean()
    }
    return batting, agg

def compute_bowling_kpis(df):
    bowling = df[df['role'].str.contains('bowl', case=False, na=False)].copy()
    if bowling.empty:
        return pd.DataFrame(), {}
    bowling['overs'] = pd.to_numeric(bowling['overs'], errors='coerce').fillna(0)
    bowling['economy'] = bowling.apply(lambda r: (r['runs_conceded'] / r['overs']) if (r['overs'] and r['overs']>0) else np.nan, axis=1)
    agg = {
        'matches': len(bowling),
        'avg_wickets': bowling['wickets'].mean(),
        'median_economy': bowling['economy'].median()
    }
    return bowling, agg

def detect_patterns(batting_df, bowling_df):
    patterns = []
    if batting_df is not None and not batting_df.empty:
        early_deaths = batting_df[batting_df['balls'] <= 20]
        if len(early_deaths):
            avg_early_sr = early_deaths['strike_rate'].mean()
            if avg_early_sr < 80:
                patterns.append("Tends to have low strike rate in first 20 balls (slow starts).")
        dot_avg = batting_df['dot_ball_pct'].mean()
        if not np.isnan(dot_avg) and dot_avg > 0.25:
            patterns.append(f"High dot ball percentage (~{dot_avg:.2f}). May be losing momentum between boundaries.")
    if bowling_df is not None and not bowling_df.empty:
        high_econ = bowling_df[bowling_df['economy'] > 7]
        if len(high_econ) / len(bowling_df) > 0.4:
            patterns.append("Bowling economy is high in many matches; consider improving line/length consistency.")
    return patterns
