import os
import openai

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
if OPENAI_API_KEY:
    openai.api_key = OPENAI_API_KEY

COACH_PROMPT_TEMPLATE = """You are an expert cricket coach. Given the player's recent aggregated stats and detected patterns, produce:
1) 2 concise strengths
2) 2 concise weaknesses
3) 4 actionable drills or tips the player can practice in the next 2 weeks (short, clear steps)
4) One focused training plan (7 days) — daily micro-goal list.

Player aggregate summary:
{summary}

Detected patterns:
{patterns}

Return only a JSON object with keys: strengths, weaknesses, drills, weekly_plan.
"""

def ask_coach(summary_text, patterns_list, model="gpt-4o-mini"):
    prompt = COACH_PROMPT_TEMPLATE.format(summary=summary_text, patterns="\n".join(patterns_list))
    try:
        resp = openai.ChatCompletion.create(
            model=model,
            messages=[
                {"role":"system","content":"You are a helpful assistant that outputs JSON and no extra commentary."},
                {"role":"user","content":prompt}
            ],
            max_tokens=400,
            temperature=0.6
        )
        return resp['choices'][0]['message']['content']
    except Exception as e:
        return {"error": str(e)}
